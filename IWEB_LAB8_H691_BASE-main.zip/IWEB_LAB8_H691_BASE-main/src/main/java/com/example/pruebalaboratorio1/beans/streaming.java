package com.example.pruebalaboratorio1.beans;

public class streaming {


}
